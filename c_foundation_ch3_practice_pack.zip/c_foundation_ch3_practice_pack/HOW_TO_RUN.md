# How to Run the Pack

From the root directory:

```bash
cd c_foundation_ch3_practice_pack
```

Run one assignment:

```bash
cd assignments/02_stdio_loops_functions
./check.sh
```

Run all assignment checks:

```bash
./tools/run_all_checks.sh
```

Most starter code intentionally fails at first. That is the point. Your job is to complete the TODOs until the tests pass.

## Recommended workflow per assignment

```bash
cd assignments/ASSIGNMENT_NAME
make
./check.sh
```

When something fails:

```bash
gdb ./program_name
valgrind --leak-check=full ./program_name
```

## Git workflow

Create your own repository at the root of this pack:

```bash
git init
git add .
git commit -m "start c foundation practice pack"
```

After each assignment:

```bash
git status
git add .
git commit -m "complete assignment XX"
```
