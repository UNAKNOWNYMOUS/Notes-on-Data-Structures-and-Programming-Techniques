#!/usr/bin/env bash
set -euo pipefail
fail() { echo "FAIL: $1"; exit 1; }

[[ -d workspace/notes ]] || fail "missing workspace/notes"
[[ -d workspace/src ]] || fail "missing workspace/src"
[[ -d workspace/data ]] || fail "missing workspace/data"
[[ -f workspace/notes/shell_notes.txt ]] || fail "missing shell_notes.txt"
[[ -f workspace/notes/git_notes.txt ]] || fail "missing git_notes.txt"
[[ -f workspace/src/scratch.c ]] || fail "missing scratch.c"
[[ -f workspace/data/numbers.txt ]] || fail "missing numbers.txt"
[[ -d workspace/.git ]] || fail "workspace is not a git repo"

grep -qi "git version" workspace/notes/git_notes.txt || fail "git_notes.txt should include git --version output"
[[ $(grep -E '^[0-9]+$' workspace/data/numbers.txt | wc -l) -eq 4 ]] || fail "numbers.txt should contain four numeric lines"

gcc -std=c11 -Wall -Wextra -Werror -pedantic workspace/src/scratch.c -o /tmp/scratch_check
out=$(/tmp/scratch_check)
[[ "$out" == "setup complete" ]] || fail "scratch.c should print exactly: setup complete"

echo "PASS: setup structure and scratch program look good"
