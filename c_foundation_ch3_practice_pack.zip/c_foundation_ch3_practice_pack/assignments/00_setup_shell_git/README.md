# Assignment 00: Setup, Shell, Git, and Directory Comfort

## Read first

- Yale CPSC 223 Section 2.4: Developing on your own machine
- Yale CPSC 223 Section 2.5: How to compile and run programs
- Yale CPSC 223 Section 3.1: The shell
- Yale CPSC 223 Section 3.6: Version control

## Goal

Become comfortable moving around a Unix-like environment and organizing your work like a developer.

## Tasks

From inside this assignment directory, create the following structure:

```text
workspace/
  notes/
    shell_notes.txt
    git_notes.txt
  src/
    scratch.c
  data/
    numbers.txt
```

Fill the files with:

`notes/shell_notes.txt`:

- at least 5 shell commands you learned
- one sentence for each command explaining what it does

`notes/git_notes.txt`:

- the output of `git --version`
- the difference between `git add` and `git commit`

`src/scratch.c`:

- a minimal C program that prints `setup complete`

`data/numbers.txt`:

```text
10
20
30
40
```

Then initialize a Git repository inside `workspace/` and make at least one commit.

## Correctness check

Run:

```bash
./check.sh
```

This checks the folder structure, file contents, C compilation, program output, and whether a Git repo exists.

## Reflection

Add your answers to `REFLECTION.md`:

1. What does `pwd` tell you?
2. What is the difference between an absolute path and a relative path?
3. What does `>` do in the shell?
4. What does a Git commit represent?
