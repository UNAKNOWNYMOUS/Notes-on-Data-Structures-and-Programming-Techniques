# Assignment 03: Arrays, Strings, and Structs

## Read first

- Dive Into Systems 1.5: Arrays and Strings
- Dive Into Systems 1.6: Structs
- Dive Into Systems 2.5-2.7: arrays, strings, structs in deeper C

## Goal

Build a small record-processing program using arrays, strings, and structs.

## Assignment

Complete `src/gradebook.c`.

Input format on stdin:

```text
name score
name score
...
```

Example:

```text
alice 90
bob 70
chris 100
```

Your program should store up to 100 students in an array of structs and print:

```text
count=3
average=86.67
top=chris 100
```

Rules:

- Student names are one word, max 31 characters.
- Scores are integers.
- If there is no input, print exactly `count=0`.
- Use a `struct Student`.
- Use helper functions.

## Correctness check

Run:

```bash
./check.sh
```

## Reflection

Add your answers to `REFLECTION.md`:

1. Why does a C string need space for `\0`?
2. Why use `char name[32]` instead of `char *name` for this assignment?
3. What is the difference between an array of structs and a struct containing arrays?
