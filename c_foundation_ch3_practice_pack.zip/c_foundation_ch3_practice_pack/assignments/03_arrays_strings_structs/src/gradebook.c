#include <stdio.h>

#define MAX_STUDENTS 100
#define NAME_SIZE 32

struct Student {
    char name[NAME_SIZE];
    int score;
};

int main(void) {
    // TODO: Read "name score" pairs from stdin into an array of struct Student.
    // Then print count, average, and top student using the exact format in README.md.
    return 0;
}
