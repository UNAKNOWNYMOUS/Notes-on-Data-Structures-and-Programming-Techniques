#!/usr/bin/env bash
set -euo pipefail
fail() { echo "FAIL: $1"; exit 1; }

make clean >/dev/null 2>&1 || true
make >/dev/null

check_case() {
  local input="$1"
  local expected="$2"
  local got
  got=$(printf "%b" "$input" | ./gradebook)
  if [[ "$got" != "$expected" ]]; then
    echo "Input:"
    printf "%b" "$input"
    echo "Expected:"
    printf '%s\n' "$expected"
    echo "Got:"
    printf '%s\n' "$got"
    fail "output mismatch"
  fi
}

check_case "" "count=0"
check_case "alice 90\nbob 70\nchris 100\n" $'count=3\naverage=86.67\ntop=chris 100'
check_case "zara 88\nyusuf 88\n" $'count=2\naverage=88.00\ntop=zara 88'

echo "PASS: gradebook behavior is correct"
