#include <stdio.h>

int main(int argc, char **argv) {
    // TODO:
    // If the user passes a name as argv[1], print: Hello, NAME!
    // Otherwise print: Hello, world!
    (void)argc;
    (void)argv;
    return 0;
}
