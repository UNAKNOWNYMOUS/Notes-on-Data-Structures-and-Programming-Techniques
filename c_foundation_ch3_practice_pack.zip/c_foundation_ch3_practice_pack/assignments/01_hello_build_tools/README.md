# Assignment 01: Hello Build Tools

## Read first

- Dive Into Systems 1.1-1.4
- Yale Section 2.5: How to compile and run programs
- Yale Section 3.3: gcc and Make

## Goal

Write small C programs, compile them manually, then build them with Make.

## Assignment

Complete `src/hello.c` so that:

```bash
./hello Ahssan
```

prints exactly:

```text
Hello, Ahssan!
```

If no argument is provided:

```bash
./hello
```

print exactly:

```text
Hello, world!
```

Then complete the Makefile so this works:

```bash
make
./hello
make clean
```

## Constraints

- Use `printf`.
- Use `argc` and `argv`.
- No hardcoded special case for `Ahssan`; any name should work.
- Program must compile cleanly with warnings enabled.

## Correctness check

Run:

```bash
./check.sh
```

## Reflection

Add your answers to `REFLECTION.md`:

1. What is `argc`?
2. What is `argv[0]`?
3. What does `make clean` usually do?
4. Why is `-Wall -Wextra -Werror` useful?
