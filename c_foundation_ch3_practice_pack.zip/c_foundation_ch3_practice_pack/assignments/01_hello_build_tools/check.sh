#!/usr/bin/env bash
set -euo pipefail
fail() { echo "FAIL: $1"; exit 1; }

make clean >/dev/null 2>&1 || true
make >/dev/null
[[ -x ./hello ]] || fail "hello executable not created"

out=$(./hello)
[[ "$out" == "Hello, world!" ]] || fail "./hello output was: '$out'"

out=$(./hello Ahssan)
[[ "$out" == "Hello, Ahssan!" ]] || fail "./hello Ahssan output was: '$out'"

out=$(./hello Linux)
[[ "$out" == "Hello, Linux!" ]] || fail "./hello Linux output was: '$out'"

make clean >/dev/null
[[ ! -e ./hello ]] || fail "make clean should remove hello"

echo "PASS: hello program and Makefile are correct"
