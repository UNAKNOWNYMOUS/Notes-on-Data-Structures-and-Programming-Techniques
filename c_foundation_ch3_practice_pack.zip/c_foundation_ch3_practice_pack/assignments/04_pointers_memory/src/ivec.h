#ifndef IVEC_H
#define IVEC_H

#include <stddef.h>

struct IVec {
    int *data;
    size_t size;
    size_t capacity;
};

int ivec_init(struct IVec *v);
void ivec_destroy(struct IVec *v);
size_t ivec_size(const struct IVec *v);
size_t ivec_capacity(const struct IVec *v);
int ivec_push_back(struct IVec *v, int value);
int ivec_get(const struct IVec *v, size_t index, int *out);
int ivec_set(struct IVec *v, size_t index, int value);
long ivec_sum(const struct IVec *v);

#endif
