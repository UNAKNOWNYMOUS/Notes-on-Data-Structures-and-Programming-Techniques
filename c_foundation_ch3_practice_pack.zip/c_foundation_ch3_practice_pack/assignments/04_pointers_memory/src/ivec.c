#include "ivec.h"
#include <stdlib.h>

int ivec_init(struct IVec *v) {
    // TODO: initialize v with capacity at least 4.
    // Return 0 on success, -1 on allocation failure.
    (void)v;
    return -1;
}

void ivec_destroy(struct IVec *v) {
    // TODO: free memory and reset fields.
    (void)v;
}

size_t ivec_size(const struct IVec *v) {
    // TODO
    (void)v;
    return 0;
}

size_t ivec_capacity(const struct IVec *v) {
    // TODO
    (void)v;
    return 0;
}

int ivec_push_back(struct IVec *v, int value) {
    // TODO: grow when needed.
    (void)v;
    (void)value;
    return -1;
}

int ivec_get(const struct IVec *v, size_t index, int *out) {
    // TODO: return -1 on bad index or NULL out.
    (void)v;
    (void)index;
    (void)out;
    return -1;
}

int ivec_set(struct IVec *v, size_t index, int value) {
    // TODO: return -1 on bad index.
    (void)v;
    (void)index;
    (void)value;
    return -1;
}

long ivec_sum(const struct IVec *v) {
    // TODO
    (void)v;
    return 0;
}
