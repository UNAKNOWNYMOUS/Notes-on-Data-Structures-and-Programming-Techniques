# Assignment 04: Pointers, Dynamic Memory, and a Tiny Vector

## Read first

- Dive Into Systems 2.1: program memory and scope
- Dive Into Systems 2.2: pointer variables
- Dive Into Systems 2.3: pointers and functions
- Dive Into Systems 2.4: dynamic memory allocation
- Yale Section 3.4.4: Valgrind

## Goal

Build a small dynamic array library in C.

This is the assignment that tells you whether you are ready to start C++ Primer soon.

## Assignment

Complete the functions in:

- `src/ivec.h`
- `src/ivec.c`

The vector stores integers and supports:

- create
- destroy
- push back
- get
- set
- size
- capacity
- sum

## Required behavior

- Initial capacity should be at least 4.
- Capacity should grow when needed.
- `ivec_get` and `ivec_set` should return `0` on success and `-1` on invalid index.
- No memory leaks.
- No invalid reads/writes.

## Correctness check

Run:

```bash
./check.sh
```

If Valgrind is installed, the script also runs Valgrind.

## Reflection

Add your answers to `REFLECTION.md`:

1. What lives on the heap in your vector?
2. What lives on the stack?
3. Why does `ivec_push_back` sometimes need `realloc`?
4. What should happen if allocation fails?
