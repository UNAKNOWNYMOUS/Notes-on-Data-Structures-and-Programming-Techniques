#!/usr/bin/env bash
set -euo pipefail
fail() { echo "FAIL: $1"; exit 1; }

make clean >/dev/null 2>&1 || true
make >/dev/null
./test_ivec | grep -q "ivec tests passed" || fail "unit tests failed"

if command -v valgrind >/dev/null 2>&1; then
  make clean >/dev/null
  gcc -std=c11 -Wall -Wextra -Werror -pedantic -g -I./src src/ivec.c tests/test_ivec.c -o test_ivec_valgrind
  valgrind --leak-check=full --error-exitcode=99 ./test_ivec_valgrind >/tmp/ivec_valgrind.out 2>&1 || {
    cat /tmp/ivec_valgrind.out
    fail "valgrind found memory problems"
  }
  rm -f test_ivec_valgrind
else
  echo "NOTE: valgrind not installed; skipping valgrind check"
fi

echo "PASS: ivec tests and memory checks passed"
