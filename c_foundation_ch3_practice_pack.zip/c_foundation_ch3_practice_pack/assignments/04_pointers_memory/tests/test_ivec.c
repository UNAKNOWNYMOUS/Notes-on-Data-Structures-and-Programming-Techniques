#include "../src/ivec.h"
#include <assert.h>
#include <stdio.h>

int main(void) {
    struct IVec v;
    assert(ivec_init(&v) == 0);
    assert(ivec_size(&v) == 0);
    assert(ivec_capacity(&v) >= 4);

    for (int i = 1; i <= 100; i++) {
        assert(ivec_push_back(&v, i) == 0);
    }

    assert(ivec_size(&v) == 100);
    assert(ivec_capacity(&v) >= 100);
    assert(ivec_sum(&v) == 5050);

    int out = 0;
    assert(ivec_get(&v, 0, &out) == 0 && out == 1);
    assert(ivec_get(&v, 99, &out) == 0 && out == 100);
    assert(ivec_get(&v, 100, &out) == -1);
    assert(ivec_get(&v, 0, NULL) == -1);

    assert(ivec_set(&v, 0, 500) == 0);
    assert(ivec_get(&v, 0, &out) == 0 && out == 500);
    assert(ivec_sum(&v) == 5549);
    assert(ivec_set(&v, 100, 1) == -1);

    ivec_destroy(&v);
    assert(v.data == NULL);
    assert(v.size == 0);
    assert(v.capacity == 0);

    puts("ivec tests passed");
    return 0;
}
