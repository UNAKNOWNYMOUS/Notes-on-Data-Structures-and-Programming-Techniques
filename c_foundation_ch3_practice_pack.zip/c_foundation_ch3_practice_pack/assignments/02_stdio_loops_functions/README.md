# Assignment 02: stdin, stdout, Loops, and Functions

## Read first

- Dive Into Systems 1.2: Input/Output
- Dive Into Systems 1.3: Conditionals and Loops
- Dive Into Systems 1.4: Functions
- Yale Section 3.1.6: Redirecting input and output

## Goal

Practice stream-style programs: read from stdin, process, print to stdout.

## Assignment

Complete `src/numstats.c`.

The program reads integers from standard input until EOF and prints:

```text
count=<N>
sum=<SUM>
min=<MIN>
max=<MAX>
avg=<AVG>
```

Rules:

- If there are no numbers, print exactly:

```text
count=0
```

- Average should print with 2 decimal places.
- Negative numbers must work.
- Use at least one helper function.

Example:

```bash
printf "10\n20\n-5\n" | ./numstats
```

Expected output:

```text
count=3
sum=25
min=-5
max=20
avg=8.33
```

## Correctness check

Run:

```bash
./check.sh
```

## Reflection

Add your answers to `REFLECTION.md`:

1. What does EOF mean?
2. Why is a streaming program useful?
3. What bug could happen if you try to print min/max before reading any numbers?
