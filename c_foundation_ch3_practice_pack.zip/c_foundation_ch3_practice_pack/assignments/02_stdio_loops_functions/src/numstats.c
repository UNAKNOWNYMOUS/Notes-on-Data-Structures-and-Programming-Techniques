#include <stdio.h>

// TODO: You may add helper functions here.

int main(void) {
    // TODO: Read integers from stdin until EOF.
    // Print stats using the exact format in README.md.
    return 0;
}
