#!/usr/bin/env bash
set -euo pipefail
fail() { echo "FAIL: $1"; exit 1; }

make clean >/dev/null 2>&1 || true
make >/dev/null

check_case() {
  local input="$1"
  local expected="$2"
  local got
  got=$(printf "%b" "$input" | ./numstats)
  if [[ "$got" != "$expected" ]]; then
    echo "Input:"
    printf "%b" "$input"
    echo "Expected:"
    printf '%s\n' "$expected"
    echo "Got:"
    printf '%s\n' "$got"
    fail "output mismatch"
  fi
}

check_case "" "count=0"
check_case "10\n20\n-5\n" $'count=3\nsum=25\nmin=-5\nmax=20\navg=8.33'
check_case "7\n" $'count=1\nsum=7\nmin=7\nmax=7\navg=7.00'
check_case "-10\n-20\n-30\n" $'count=3\nsum=-60\nmin=-30\nmax=-10\navg=-20.00'

echo "PASS: numstats behavior is correct"
