#include <stdio.h>

int average(const int *values, int count) {
    int sum = 0;
    // BUG: reads one element past the end.
    for (int i = 0; i <= count; i++) {
        sum += values[i];
    }
    return sum / count;
}

int main(void) {
    int values[] = {10, 20, 30, 40};
    printf("average=%d\n", average(values, 4));
    return 0;
}
