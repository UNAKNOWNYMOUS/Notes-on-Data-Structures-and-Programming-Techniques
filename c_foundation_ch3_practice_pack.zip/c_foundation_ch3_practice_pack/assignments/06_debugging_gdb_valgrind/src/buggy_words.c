#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *copy_word(const char *word) {
    // BUG: not enough space for the null terminator.
    char *copy = malloc(strlen(word));
    if (copy == NULL) {
        return NULL;
    }
    strcpy(copy, word);
    return copy;
}

int main(void) {
    char *a = copy_word("systems");
    char *b = copy_word("debugging");

    if (a == NULL || b == NULL) {
        free(a);
        free(b);
        return 1;
    }

    printf("%s %s\n", a, b);

    // BUG: one allocation is leaked.
    free(a);
    return 0;
}
