#!/usr/bin/env bash
set -euo pipefail
fail() { echo "FAIL: $1"; exit 1; }

make clean >/dev/null 2>&1 || true
make >/dev/null

out=$(./buggy_words)
[[ "$out" == "systems debugging" ]] || fail "buggy_words output mismatch: $out"

out=$(./buggy_average)
[[ "$out" == "average=25" ]] || fail "buggy_average output mismatch: $out"

[[ -f DEBUG_LOG.md ]] || fail "missing DEBUG_LOG.md"
grep -q "buggy_words.c" DEBUG_LOG.md || fail "DEBUG_LOG.md missing buggy_words.c section"
grep -q "buggy_average.c" DEBUG_LOG.md || fail "DEBUG_LOG.md missing buggy_average.c section"
grep -qi "Root cause" DEBUG_LOG.md || fail "DEBUG_LOG.md missing Root cause fields"
grep -qi "Fix" DEBUG_LOG.md || fail "DEBUG_LOG.md missing Fix fields"

if command -v valgrind >/dev/null 2>&1; then
  gcc -std=c11 -Wall -Wextra -Werror -pedantic -g src/buggy_words.c -o buggy_words_valgrind
  valgrind --leak-check=full --error-exitcode=99 ./buggy_words_valgrind >/tmp/words_valgrind.out 2>&1 || {
    cat /tmp/words_valgrind.out
    fail "valgrind found problems in buggy_words"
  }
  gcc -std=c11 -Wall -Wextra -Werror -pedantic -g src/buggy_average.c -o buggy_average_valgrind
  valgrind --leak-check=full --error-exitcode=99 ./buggy_average_valgrind >/tmp/avg_valgrind.out 2>&1 || {
    cat /tmp/avg_valgrind.out
    fail "valgrind found problems in buggy_average"
  }
else
  echo "NOTE: valgrind not installed; skipping valgrind check"
fi

echo "PASS: debugging fixes look correct"
