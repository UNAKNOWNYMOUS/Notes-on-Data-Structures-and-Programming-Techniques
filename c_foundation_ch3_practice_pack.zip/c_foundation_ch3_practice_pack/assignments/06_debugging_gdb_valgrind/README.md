# Assignment 06: Debugging with GDB and Valgrind

## Read first

- Dive Into Systems Chapter 3: C Debugging Tools
- Yale Section 3.4: Debugging tools

## Goal

Learn to debug instead of guessing.

## Assignment

There are two buggy programs:

1. `src/buggy_words.c`
2. `src/buggy_average.c`

Your job:

- Build them with `make`.
- Run them.
- Observe the failure.
- Use GDB and/or Valgrind to find the bug.
- Fix the code.
- Write a debugging log in `DEBUG_LOG.md`.

## Required DEBUG_LOG.md format

Create a file named `DEBUG_LOG.md` with this structure:

```markdown
# Debug Log

## buggy_words.c

- Symptom:
- Tool used:
- Command used:
- Root cause:
- Fix:

## buggy_average.c

- Symptom:
- Tool used:
- Command used:
- Root cause:
- Fix:
```

## Correctness check

Run:

```bash
./check.sh
```

This checks:

- expected output
- sanitizer errors
- optional Valgrind errors
- that `DEBUG_LOG.md` exists and includes key fields

## Hints

Try these:

```bash
gdb ./buggy_words
run
bt
break main
next
print variable_name
```

And:

```bash
valgrind --leak-check=full ./buggy_words
```
