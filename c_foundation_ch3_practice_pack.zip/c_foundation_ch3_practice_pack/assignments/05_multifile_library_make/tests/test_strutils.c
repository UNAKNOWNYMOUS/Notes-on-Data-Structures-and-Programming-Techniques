#include "../src/strutils.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>

int main(void) {
    assert(count_char("banana", 'a') == 3);
    assert(count_char("banana", 'z') == 0);
    assert(count_char("", 'x') == 0);
    assert(count_char(NULL, 'x') == 0);

    char a[32] = "Hello, world!";
    to_upper_inplace(a);
    assert(strcmp(a, "HELLO, WORLD!") == 0);

    char b[32] = "line\n";
    trim_newline(b);
    assert(strcmp(b, "line") == 0);
    trim_newline(b);
    assert(strcmp(b, "line") == 0);

    char c[32] = "abcdef";
    reverse_inplace(c);
    assert(strcmp(c, "fedcba") == 0);

    char d[32] = "abcde";
    reverse_inplace(d);
    assert(strcmp(d, "edcba") == 0);

    char e[1] = "";
    reverse_inplace(e);
    assert(strcmp(e, "") == 0);

    puts("strutils tests passed");
    return 0;
}
