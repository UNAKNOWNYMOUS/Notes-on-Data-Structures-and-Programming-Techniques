#!/usr/bin/env bash
set -euo pipefail
fail() { echo "FAIL: $1"; exit 1; }

make clean >/dev/null 2>&1 || true
make >/dev/null
./test_strutils | grep -q "strutils tests passed" || fail "unit tests failed"

echo "PASS: strutils library works"
