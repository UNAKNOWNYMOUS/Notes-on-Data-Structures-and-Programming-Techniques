#include "strutils.h"

size_t count_char(const char *s, char target) {
    // TODO
    (void)s;
    (void)target;
    return 0;
}

void to_upper_inplace(char *s) {
    // TODO: only handle ASCII a-z.
    (void)s;
}

void trim_newline(char *s) {
    // TODO: remove one trailing '\n', if present.
    (void)s;
}

void reverse_inplace(char *s) {
    // TODO
    (void)s;
}
