#ifndef STRUTILS_H
#define STRUTILS_H

#include <stddef.h>

size_t count_char(const char *s, char target);
void to_upper_inplace(char *s);
void trim_newline(char *s);
void reverse_inplace(char *s);

#endif
