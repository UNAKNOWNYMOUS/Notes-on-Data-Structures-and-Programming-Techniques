# Assignment 05: Multi-file C Library and Make

## Read first

- Dive Into Systems 2.9.5: C libraries, compiling, and linking
- Dive Into Systems 2.9.6: writing your own C libraries and compiling multiple `.c` and `.h` files
- Yale Section 3.3.2: Make

## Goal

Practice header/source separation and build a small reusable library.

## Assignment

Complete `src/strutils.c` according to `src/strutils.h`.

Functions:

- `count_char`: count occurrences of a character
- `to_upper_inplace`: convert lowercase ASCII letters to uppercase in place
- `trim_newline`: remove one trailing newline if present
- `reverse_inplace`: reverse a string in place

## Correctness check

Run:

```bash
./check.sh
```

## Reflection

Add your answers to `REFLECTION.md`:

1. What should go in a `.h` file?
2. What should go in a `.c` file?
3. Why should header files use include guards?
4. What does the linker do?
