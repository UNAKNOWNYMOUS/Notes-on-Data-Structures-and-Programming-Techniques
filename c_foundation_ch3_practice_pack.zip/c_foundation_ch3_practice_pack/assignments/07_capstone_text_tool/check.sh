#!/usr/bin/env bash
set -euo pipefail
fail() { echo "FAIL: $1"; exit 1; }

make clean >/dev/null 2>&1 || true
make >/dev/null

check_case() {
  local input="$1"
  local expected="$2"
  local got
  got=$(printf "%b" "$input" | ./textscan)
  if [[ "$got" != "$expected" ]]; then
    echo "Input:"
    printf "%b" "$input"
    echo "Expected:"
    printf '%s\n' "$expected"
    echo "Got:"
    printf '%s\n' "$got"
    fail "output mismatch"
  fi
}

check_case "" $'lines=0\nwords=0\nchars=0\nlongest='
check_case "hello systems\nC debugging tools\n" $'lines=2\nwords=5\nchars=32\nlongest=debugging'
check_case "one two\nthree\n" $'lines=2\nwords=3\nchars=14\nlongest=three'
check_case "   spaced   out   \n" $'lines=1\nwords=2\nchars=18\nlongest=spaced'

if command -v valgrind >/dev/null 2>&1; then
  gcc -std=c11 -Wall -Wextra -Werror -pedantic -g -I./src src/main.c src/textscan.c -o textscan_valgrind
  printf "hello systems\nC debugging tools\n" | valgrind --leak-check=full --error-exitcode=99 ./textscan_valgrind >/tmp/textscan_valgrind.out 2>&1 || {
    cat /tmp/textscan_valgrind.out
    fail "valgrind found memory problems"
  }
else
  echo "NOTE: valgrind not installed; skipping valgrind check"
fi

echo "PASS: textscan capstone passed"
