#include "textscan.h"
#include <stdlib.h>

int textstats_init(struct TextStats *stats) {
    // TODO: initialize fields. longest should be a heap-allocated empty string or NULL handled safely.
    (void)stats;
    return -1;
}

void textstats_destroy(struct TextStats *stats) {
    // TODO: free any owned memory and reset fields.
    (void)stats;
}

int textstats_process_stream(struct TextStats *stats) {
    // TODO: read from stdin and update stats.
    // Return 0 on success, -1 on allocation failure.
    (void)stats;
    return -1;
}
