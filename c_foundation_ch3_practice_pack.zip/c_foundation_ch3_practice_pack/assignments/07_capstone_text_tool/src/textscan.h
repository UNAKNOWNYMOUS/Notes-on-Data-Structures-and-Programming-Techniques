#ifndef TEXTSCAN_H
#define TEXTSCAN_H

#include <stddef.h>

struct TextStats {
    long lines;
    long words;
    long chars;
    char *longest;
};

int textstats_init(struct TextStats *stats);
void textstats_destroy(struct TextStats *stats);
int textstats_process_stream(struct TextStats *stats);

#endif
