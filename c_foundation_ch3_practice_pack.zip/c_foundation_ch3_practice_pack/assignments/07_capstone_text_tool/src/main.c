#include "textscan.h"
#include <stdio.h>

int main(void) {
    struct TextStats stats;
    if (textstats_init(&stats) != 0) {
        return 1;
    }

    if (textstats_process_stream(&stats) != 0) {
        textstats_destroy(&stats);
        return 1;
    }

    printf("lines=%ld\n", stats.lines);
    printf("words=%ld\n", stats.words);
    printf("chars=%ld\n", stats.chars);
    printf("longest=%s\n", stats.longest == NULL ? "" : stats.longest);

    textstats_destroy(&stats);
    return 0;
}
