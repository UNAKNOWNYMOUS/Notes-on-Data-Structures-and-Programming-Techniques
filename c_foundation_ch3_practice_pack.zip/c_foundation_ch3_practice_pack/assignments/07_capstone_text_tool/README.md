# Assignment 07: Capstone - `textscan`

## Read first

Complete all previous assignments and read through:

- Dive Into Systems Chapters 1-3
- Yale CPSC 223 Sections 2-3

## Goal

Build a small but real command-line C program using everything so far.

## Assignment

Implement `textscan`.

It reads text from stdin and prints:

```text
lines=<N>
words=<N>
chars=<N>
longest=<WORD>
```

Rules:

- `lines` counts newline characters.
- `chars` counts all input characters, including newlines.
- `words` are separated by whitespace.
- `longest` is the longest word seen.
- If there are no words, print `longest=` with nothing after it.
- You must use dynamic memory for storing the current longest word.
- You must split code into at least two `.c` files and one `.h` file.
- You must provide a Makefile.
- No leaks or invalid memory behavior.

## Example

Input:

```text
hello systems
C debugging tools
```

Output:

```text
lines=2
words=5
chars=32
longest=debugging
```

## Correctness check

Run:

```bash
./check.sh
```

## Reflection

Add your answers to `REFLECTION.md`:

1. What part of this was hardest?
2. Where did you allocate memory?
3. Where did you free memory?
4. What did GDB or Valgrind help you catch?
5. Are you ready to start C++ Primer? Why or why not?
