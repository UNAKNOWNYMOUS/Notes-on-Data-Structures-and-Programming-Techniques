# C Foundation Practice Pack: through Dive Into Systems Ch. 3 + Yale CPSC 223 Section 3

This pack is designed for the first foundation block before you move heavily into C++ Primer.
It combines:

- Dive Into Systems Chapters 1-3:
  - Ch. 1: C basics
  - Ch. 2: deeper C, memory, pointers, dynamic allocation, strings, structs, multi-file programs
  - Ch. 3: GDB, Valgrind, debugging tools
- Yale CPSC 223 Sections 2-3:
  - local setup / compiling
  - shell, filesystem, redirection
  - editors
  - gcc, Make
  - assertions, gdb, Valgrind, performance tools, Git

## How to use this pack

Do the assignments in order. For each assignment:

1. Read the assigned sections listed in that assignment's `README.md`.
2. Complete the TODOs in the starter files.
3. Run the assignment's `check.sh` script.
4. Fix warnings, test failures, sanitizer errors, and Valgrind errors.
5. Fill out the reflection questions before moving on.

## Recommended pace

If you are studying part-time, do this over 2-4 weeks.

- Week 1: `00_setup_shell_git`, `01_hello_build_tools`, `02_stdio_loops_functions`
- Week 2: `03_arrays_strings_structs`, `04_pointers_memory`
- Week 3: `05_multifile_library_make`, `06_debugging_gdb_valgrind`
- Week 4: `07_capstone_text_tool`

## System requirements

You should have these installed:

```bash
gcc make git bash coreutils grep sed diff
```

Strongly recommended:

```bash
gdb valgrind
```

On Arch Linux:

```bash
sudo pacman -S --needed gcc make gdb valgrind git
```

## Compiler flags used in this pack

Most assignments compile with:

```bash
gcc -std=c11 -Wall -Wextra -Werror -pedantic -g -fsanitize=address,undefined
```

Meaning:

- `-std=c11`: compile as C11.
- `-Wall`: enable many common warnings.
- `-Wextra`: enable extra warnings.
- `-Werror`: treat warnings as errors.
- `-pedantic`: warn/error on non-standard C usage.
- `-g`: include debug symbols for GDB.
- `-fsanitize=address,undefined`: catch memory errors and undefined behavior.

## How correctness is checked

Correctness is checked by a mix of:

- exact output tests
- compiler warnings-as-errors
- sanitizer runs
- optional Valgrind runs
- manual reflection prompts

Passing tests does not prove your code is perfect, but it does prove you met the required behavior for this pack.
