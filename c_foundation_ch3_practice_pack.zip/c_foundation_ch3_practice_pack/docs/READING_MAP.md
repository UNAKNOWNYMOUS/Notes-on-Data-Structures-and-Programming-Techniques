# Reading Map

Use this map to know what to read before each assignment.

## Source A: Dive Into Systems

Read through Chapter 3:

- Chapter 1: By the C, the Beautiful C
  - Getting started programming in C
  - printf / scanf
  - conditionals and loops
  - functions
  - arrays and strings
  - structs
  - exercises
- Chapter 2: A Deeper Dive Into C
  - program memory and scope
  - pointer variables
  - pointers and functions
  - dynamic memory allocation
  - arrays in C
  - strings and the string library
  - structs
  - input/output in C
  - command-line arguments
  - void pointers
  - pointer arithmetic
  - compiling/linking multiple `.c` and `.h` files
  - compiling C to assembly
- Chapter 3: C Debugging Tools
  - GDB
  - detailed GDB commands
  - Valgrind
  - advanced GDB features
  - assembly debugging
  - multithreaded debugging

## Source B: Yale CPSC 223 notes

Read through Section 3:

- Section 2: The Zoo / developing on your own machine / compiling and running programs
- Section 3: The Linux programming environment
  - shell
  - filesystem
  - command-line programs
  - stopping/interrupting programs
  - input/output redirection
  - editors
  - gcc
  - Make
  - assertions
  - GDB
  - Valgrind
  - basic profiling
  - Git

## Assignment ordering

| Assignment | Do after reading |
|---|---|
| 00_setup_shell_git | Yale 2.4-2.5 and Yale 3.1, 3.6 |
| 01_hello_build_tools | Dive 1.1-1.4 and Yale 2.5, 3.3 |
| 02_stdio_loops_functions | Dive 1.2-1.4 and Yale 3.1 redirection |
| 03_arrays_strings_structs | Dive 1.5-1.6 and start Dive 2.5-2.7 |
| 04_pointers_memory | Dive 2.1-2.4 and Yale 3.4.4 Valgrind |
| 05_multifile_library_make | Dive 2.9.5-2.9.6 and Yale 3.3 Make |
| 06_debugging_gdb_valgrind | Dive 3.1-3.4 and Yale 3.4 |
| 07_capstone_text_tool | After completing all above |
