# Master Checklist

## Terminal and setup

- [ ] I can navigate with `pwd`, `ls`, `cd`.
- [ ] I can create, move, copy, and remove files/directories.
- [ ] I can redirect input/output with `<`, `>`, and pipes.
- [ ] I can compile a C file manually with `gcc`.
- [ ] I can use a Makefile.
- [ ] I can initialize a Git repo, commit changes, and inspect history.

## C basics

- [ ] I can write functions.
- [ ] I can use loops and conditionals.
- [ ] I can read from `stdin` and write to `stdout`.
- [ ] I can use arrays and strings.
- [ ] I can define and use structs.

## Deeper C

- [ ] I understand stack vs heap at a beginner level.
- [ ] I can use pointers safely.
- [ ] I can allocate memory with `malloc`/`calloc`/`realloc`.
- [ ] I can free memory exactly once.
- [ ] I can split code into `.h` and `.c` files.

## Debugging

- [ ] I can use `gdb` to set breakpoints.
- [ ] I can inspect variables in `gdb`.
- [ ] I can step through code line-by-line.
- [ ] I can catch a segmentation fault in `gdb`.
- [ ] I can use Valgrind to find leaks and invalid memory access.

## Ready to start C++ Primer?

You are ready to start C++ Primer if you can complete assignments 04-07 without relying on solutions.
