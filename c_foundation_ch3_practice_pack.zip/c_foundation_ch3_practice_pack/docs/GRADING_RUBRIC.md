# Grading Rubric

Use this to evaluate yourself after each assignment.

## 4 - Strong

- Tests pass.
- Code compiles with no warnings.
- You can explain every line you wrote.
- You used GDB/Valgrind when appropriate.
- Reflection answers are specific.

## 3 - Good

- Tests pass.
- Code is mostly clean.
- You understand the main idea but a few details are fuzzy.

## 2 - Needs review

- Some tests fail or you needed heavy hints.
- You can explain what the code does but not why it works.
- You avoided debugging tools and guessed instead.

## 1 - Redo

- Tests do not pass.
- Warnings/errors are ignored.
- You copied code without understanding.
- You cannot explain memory ownership.

## Rule before moving to C++ Primer

Before starting C++ Primer seriously, aim for:

- Assignment 04 score: 3 or 4
- Assignment 06 score: 3 or 4
- Assignment 07 score: 3 or 4
