#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
assignments=(
  "00_setup_shell_git"
  "01_hello_build_tools"
  "02_stdio_loops_functions"
  "03_arrays_strings_structs"
  "04_pointers_memory"
  "05_multifile_library_make"
  "06_debugging_gdb_valgrind"
  "07_capstone_text_tool"
)

fail=0
for a in "${assignments[@]}"; do
  echo "========== $a =========="
  if [[ -x "$ROOT/assignments/$a/check.sh" ]]; then
    (cd "$ROOT/assignments/$a" && ./check.sh)
    status=$?
    if [[ $status -ne 0 ]]; then
      echo "FAIL: $a"
      fail=1
    else
      echo "PASS: $a"
    fi
  else
    echo "No check.sh for $a"
  fi
  echo
 done
exit $fail
