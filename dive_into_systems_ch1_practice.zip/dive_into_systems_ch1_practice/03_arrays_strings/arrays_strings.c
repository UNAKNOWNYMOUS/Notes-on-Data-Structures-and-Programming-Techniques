#include <stdio.h>

int max_int(const int values[], int length) {
    /* TODO */
    (void)values;
    (void)length;
    return 0;
}

int count_vowels(const char s[]) {
    /* TODO */
    (void)s;
    return 0;
}

void reverse_copy(const char src[], char dst[], int dst_size) {
    /* TODO */
    (void)src;
    (void)dst;
    (void)dst_size;
}

#ifndef TESTING
int main(void) {
    int values[] = {3, 9, -2, 7};
    char reversed[32];
    reverse_copy("systems", reversed, 32);
    printf("max: %d\n", max_int(values, 4));
    printf("vowels: %d\n", count_vowels("Beautiful C"));
    printf("reverse: %s\n", reversed);
    return 0;
}
#endif
