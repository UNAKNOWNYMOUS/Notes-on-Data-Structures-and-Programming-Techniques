#include <assert.h>
#include <stdio.h>
#include <string.h>

int max_int(const int values[], int length);
int count_vowels(const char s[]);
void reverse_copy(const char src[], char dst[], int dst_size);

int main(void) {
    int a[] = {3, 9, -2, 7};
    int b[] = {-10, -3, -99};
    assert(max_int(a, 4) == 9);
    assert(max_int(b, 3) == -3);

    assert(count_vowels("Beautiful C") == 5);
    assert(count_vowels("xyz") == 0);
    assert(count_vowels("AEIOUaeiou") == 10);

    char out[32];
    reverse_copy("systems", out, 32);
    assert(strcmp(out, "smetsys") == 0);

    char small[4];
    reverse_copy("abcdef", small, 4);
    assert(strcmp(small, "fed") == 0);

    puts("all arrays/strings tests passed");
    return 0;
}
