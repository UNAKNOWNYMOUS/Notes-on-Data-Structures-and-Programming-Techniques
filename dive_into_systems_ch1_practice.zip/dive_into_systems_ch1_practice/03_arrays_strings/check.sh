#!/usr/bin/env bash
cd "$(dirname "$0")"
set -u
if ! gcc -std=c11 -Wall -Wextra -pedantic -g -DTESTING arrays_strings.c test_arrays_strings.c -o test_arrays_strings >/tmp/arrays_build.txt 2>&1; then
  echo "FAIL: build failed"
  cat /tmp/arrays_build.txt
  exit 1
fi
./test_arrays_strings
