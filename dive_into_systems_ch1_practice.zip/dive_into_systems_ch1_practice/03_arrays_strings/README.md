# Assignment 3 — Arrays and Strings

## Read first

Dive Into Systems Chapter 1:

- 1.5 Arrays and Strings

## Task

Complete `arrays_strings.c`.

Implement:

```c
int max_int(const int values[], int length);
int count_vowels(const char s[]);
void reverse_copy(const char src[], char dst[], int dst_size);
```

Rules:

- `max_int` returns the largest value in a non-empty array.
- `count_vowels` counts `a`, `e`, `i`, `o`, `u`, both lowercase and uppercase.
- `reverse_copy` writes the reverse of `src` into `dst` and null-terminates it.
- `reverse_copy` must not write past `dst_size` bytes.

## Check your work

```bash
bash check.sh
```
