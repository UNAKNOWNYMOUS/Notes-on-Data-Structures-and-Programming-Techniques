# Assignment 2 — Functions

## Read first

Dive Into Systems Chapter 1:

- 1.4 Functions

## Task

Complete `functions.c`.

Implement:

```c
int clamp(int value, int low, int high);
int gcd(int a, int b);
int is_prime(int n);
```

Rules:

- `clamp`: if `value < low`, return `low`; if `value > high`, return `high`; otherwise return `value`.
- `gcd`: return the greatest common divisor of two integers. The result should be nonnegative.
- `is_prime`: return 1 for prime numbers, 0 otherwise.

## Check your work

```bash
bash check.sh
```
