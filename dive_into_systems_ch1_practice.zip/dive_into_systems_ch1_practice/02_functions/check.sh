#!/usr/bin/env bash
cd "$(dirname "$0")"
set -u
if ! gcc -std=c11 -Wall -Wextra -pedantic -g -DTESTING functions.c test_functions.c -o test_functions >/tmp/functions_build.txt 2>&1; then
  echo "FAIL: build failed"
  cat /tmp/functions_build.txt
  exit 1
fi
./test_functions
