#include <assert.h>
#include <stdio.h>

int clamp(int value, int low, int high);
int gcd(int a, int b);
int is_prime(int n);

int main(void) {
    assert(clamp(15, 0, 10) == 10);
    assert(clamp(-2, 0, 10) == 0);
    assert(clamp(7, 0, 10) == 7);

    assert(gcd(84, 30) == 6);
    assert(gcd(30, 84) == 6);
    assert(gcd(-30, 84) == 6);
    assert(gcd(0, 9) == 9);

    assert(is_prime(2) == 1);
    assert(is_prime(29) == 1);
    assert(is_prime(1) == 0);
    assert(is_prime(0) == 0);
    assert(is_prime(100) == 0);

    puts("all function tests passed");
    return 0;
}
