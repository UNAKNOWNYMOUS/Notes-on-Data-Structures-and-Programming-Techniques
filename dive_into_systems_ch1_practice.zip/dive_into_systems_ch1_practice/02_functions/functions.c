#include <stdio.h>

int clamp(int value, int low, int high) {
    /* TODO */
    (void)value;
    (void)low;
    (void)high;
    return 0;
}

int gcd(int a, int b) {
    /* TODO */
    (void)a;
    (void)b;
    return 0;
}

int is_prime(int n) {
    /* TODO */
    (void)n;
    return 0;
}

#ifndef TESTING
int main(void) {
    printf("clamp(15, 0, 10) = %d\n", clamp(15, 0, 10));
    printf("gcd(84, 30) = %d\n", gcd(84, 30));
    printf("is_prime(29) = %d\n", is_prime(29));
    return 0;
}
#endif
