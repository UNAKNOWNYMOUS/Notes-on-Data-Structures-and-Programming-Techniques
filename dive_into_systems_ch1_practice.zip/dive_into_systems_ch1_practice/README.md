# Dive Into Systems Practice Pack — Through Chapter 1

This practice pack is for **Dive Into Systems, Chapter 1: By the C, the Beautiful C**.

Chapter 1 covers the first practical C skills: getting started, `printf`/`scanf`, conditionals and loops, functions, arrays and strings, structs, summary, and exercises.

## How to use this archive

Work in order:

1. `00_reading_map.md`
2. `01_input_output_control/`
3. `02_functions/`
4. `03_arrays_strings/`
5. `04_structs/`
6. `05_chapter_project_gradebook/`

At the end, run:

```bash
./run_all_checks.sh
```

## Style rule

Use the C features from Chapter 1 only as much as possible:

- `printf`, `scanf`
- variables and arithmetic
- `if`/`else`
- `while`/`for`
- functions
- arrays
- strings as `char[]` / `char *`
- structs

Avoid advanced dynamic memory until Dive Chapter 2.
