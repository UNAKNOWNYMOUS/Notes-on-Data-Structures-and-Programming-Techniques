#!/usr/bin/env bash
cd "$(dirname "$0")"
set -u
fail=0

if ! gcc -std=c11 -Wall -Wextra -pedantic -g classify_numbers.c -o classify_numbers >/tmp/classify_build.txt 2>&1; then
  echo "FAIL: build failed"
  cat /tmp/classify_build.txt
  exit 1
fi

run_case() {
  local input="$1"
  local expected="$2"
  local got
  got=$(printf "%b" "$input" | ./classify_numbers)
  if [ "$got" = "$expected" ]; then
    echo "OK: input [$input]"
  else
    echo "FAIL: input [$input]"
    echo "Expected:"
    printf '%s\n' "$expected"
    echo "Got:"
    printf '%s\n' "$got"
    fail=1
  fi
}

run_case "1 2 -3 0 4\n" $'count: 5\nsum: 4\nevens: 3\nodds: 2\npositives: 3\nnegatives: 1\nzeros: 1'
run_case "\n" $'count: 0\nsum: 0\nevens: 0\nodds: 0\npositives: 0\nnegatives: 0\nzeros: 0'
run_case "-2 -4 -5 7 0\n" $'count: 5\nsum: -4\nevens: 3\nodds: 2\npositives: 1\nnegatives: 3\nzeros: 1'

exit "$fail"
