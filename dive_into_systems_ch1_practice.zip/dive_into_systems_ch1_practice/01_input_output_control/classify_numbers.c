#include <stdio.h>

int main(void) {
    /* TODO: read ints until EOF using scanf.
       Track count, sum, evens, odds, positives, negatives, zeros.
       Print the exact summary format from README.md.
    */
    return 0;
}
