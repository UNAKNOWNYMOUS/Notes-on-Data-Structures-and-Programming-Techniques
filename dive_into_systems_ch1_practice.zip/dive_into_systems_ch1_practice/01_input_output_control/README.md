# Assignment 1 — Input, Output, Conditionals, and Loops

## Read first

Dive Into Systems Chapter 1:

- 1.1 Getting Started Programming in C
- 1.2 Input/Output
- 1.3 Conditionals and Loops

## Task

Complete `classify_numbers.c`.

The program reads integers from `stdin` until EOF and prints exactly these summary lines:

```text
count: N
sum: S
evens: E
odds: O
positives: P
negatives: M
zeros: Z
```

Definitions:

- zero is even
- positive means greater than 0
- negative means less than 0
- if there are no numbers, count and all totals should be 0

Example:

```bash
printf "1 2 -3 0 4\n" | ./classify_numbers
```

Expected:

```text
count: 5
sum: 4
evens: 3
odds: 2
positives: 3
negatives: 1
zeros: 1
```

## Check your work

```bash
bash check.sh
```
