# Reading Map — Dive Into Systems Chapter 1

Read the web chapter in this order and do the matching assignment after each group.

## 1.1 Getting Started Programming in C

After reading, make sure you can:

- write a `main` function
- include headers
- compile a `.c` file with `gcc`
- run the executable

Practice:

- Start `01_input_output_control/`

## 1.2 Input/Output

After reading, make sure you can:

- print with `printf`
- read with `scanf`
- use format specifiers for `int`, `double`, and strings

Practice:

- Finish the input/output portion of `01_input_output_control/`

## 1.3 Conditionals and Loops

After reading, make sure you can:

- use `if`, `else if`, and `else`
- use `while` and `for` loops
- process input until EOF

Practice:

- Finish all of `01_input_output_control/`

## 1.4 Functions

After reading, make sure you can:

- define functions above or below `main` with prototypes
- pass arguments
- return values
- separate testing logic from implementation logic

Practice:

- Complete `02_functions/`

## 1.5 Arrays and Strings

After reading, make sure you can:

- create and index arrays
- process arrays with loops
- process C strings character-by-character
- handle the null terminator `\0`

Practice:

- Complete `03_arrays_strings/`

## 1.6 Structs

After reading, make sure you can:

- define a struct type
- access fields with `.`
- pass structs to functions
- store structs in arrays

Practice:

- Complete `04_structs/`
- Complete `05_chapter_project_gradebook/`

## 1.7–1.8 Summary and Exercises

After reading, do the official chapter exercises from the website.

Then run:

```bash
./run_all_checks.sh
```
