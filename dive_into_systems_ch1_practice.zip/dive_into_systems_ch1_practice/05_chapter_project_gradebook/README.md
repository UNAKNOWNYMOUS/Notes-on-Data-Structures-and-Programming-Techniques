# Assignment 5 — Chapter 1 Project: Mini Gradebook

## Read first

Finish all of Dive Into Systems Chapter 1, especially:

- 1.2 Input/Output
- 1.3 Conditionals and Loops
- 1.4 Functions
- 1.5 Arrays and Strings
- 1.6 Structs

## Task

Complete `gradebook.c`.

The program reads records from `stdin` in this format:

```text
name score
```

Example:

```text
Aisha 92
Omar 75
Mina 88
```

Assumptions:

- Names have no spaces.
- Names are at most 31 characters.
- Scores are integers.
- There will be at most 100 records.

Print exactly:

```text
count: N
average: A.BB
top: NAME SCORE
passing: P
```

Rules:

- Passing means score >= 70.
- Top is the first student with the highest score if there is a tie.
- If there is no input, print:

```text
count: 0
average: 0.00
top: none
passing: 0
```

## Check your work

```bash
bash check.sh
```
