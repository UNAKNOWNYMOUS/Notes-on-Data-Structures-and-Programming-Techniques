#!/usr/bin/env bash
cd "$(dirname "$0")"
set -u
fail=0

if ! gcc -std=c11 -Wall -Wextra -pedantic -g gradebook.c -o gradebook >/tmp/gradebook_build.txt 2>&1; then
  echo "FAIL: build failed"
  cat /tmp/gradebook_build.txt
  exit 1
fi

run_case() {
  local input="$1"
  local expected="$2"
  local got
  got=$(printf "%b" "$input" | ./gradebook)
  if [ "$got" = "$expected" ]; then
    echo "OK: case"
  else
    echo "FAIL: case"
    echo "Input:"
    printf "%b\n" "$input"
    echo "Expected:"
    printf "%s\n" "$expected"
    echo "Got:"
    printf "%s\n" "$got"
    fail=1
  fi
}

run_case $'Aisha 92\nOmar 75\nMina 88\n' $'count: 3\naverage: 85.00\ntop: Aisha 92\npassing: 3'
run_case $'Bilal 65\nNoor 70\nMusa 70\n' $'count: 3\naverage: 68.33\ntop: Noor 70\npassing: 2'
run_case $'' $'count: 0\naverage: 0.00\ntop: none\npassing: 0'

exit "$fail"
