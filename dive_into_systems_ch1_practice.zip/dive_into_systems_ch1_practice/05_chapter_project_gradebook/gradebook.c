#include <stdio.h>

#define MAX_STUDENTS 100
#define MAX_NAME 32

struct Student {
    char name[MAX_NAME];
    int score;
};

int main(void) {
    /* TODO:
       - read up to MAX_STUDENTS records from stdin
       - store them in an array of struct Student
       - compute count, average, top student, passing count
       - print exact format from README.md
    */
    return 0;
}
