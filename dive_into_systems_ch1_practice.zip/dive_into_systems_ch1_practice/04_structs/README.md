# Assignment 4 — Structs

## Read first

Dive Into Systems Chapter 1:

- 1.6 Structs

## Task

Complete `structs.c`.

You are working with points and rectangles.

Implement:

```c
struct Point make_point(int x, int y);
struct Rectangle make_rectangle(struct Point top_left, int width, int height);
int area(struct Rectangle r);
int contains(struct Rectangle r, struct Point p);
```

Coordinate rule:

- `top_left` is the upper-left corner.
- `width` and `height` are positive.
- A point is inside the rectangle if:
  - `x >= top_left.x`
  - `x < top_left.x + width`
  - `y >= top_left.y`
  - `y < top_left.y + height`

## Check your work

```bash
bash check.sh
```
