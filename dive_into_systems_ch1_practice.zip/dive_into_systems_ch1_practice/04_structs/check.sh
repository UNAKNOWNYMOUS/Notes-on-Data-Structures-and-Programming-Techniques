#!/usr/bin/env bash
cd "$(dirname "$0")"
set -u
if ! gcc -std=c11 -Wall -Wextra -pedantic -g -DTESTING structs.c test_structs.c -o test_structs >/tmp/structs_build.txt 2>&1; then
  echo "FAIL: build failed"
  cat /tmp/structs_build.txt
  exit 1
fi
./test_structs
