#include <stdio.h>

struct Point {
    int x;
    int y;
};

struct Rectangle {
    struct Point top_left;
    int width;
    int height;
};

struct Point make_point(int x, int y) {
    /* TODO */
    struct Point p = {0, 0};
    (void)x;
    (void)y;
    return p;
}

struct Rectangle make_rectangle(struct Point top_left, int width, int height) {
    /* TODO */
    struct Rectangle r = {{0, 0}, 0, 0};
    (void)top_left;
    (void)width;
    (void)height;
    return r;
}

int area(struct Rectangle r) {
    /* TODO */
    (void)r;
    return 0;
}

int contains(struct Rectangle r, struct Point p) {
    /* TODO */
    (void)r;
    (void)p;
    return 0;
}

#ifndef TESTING
int main(void) {
    struct Rectangle r = make_rectangle(make_point(10, 20), 5, 3);
    printf("area: %d\n", area(r));
    printf("contains 12,21: %d\n", contains(r, make_point(12, 21)));
    return 0;
}
#endif
