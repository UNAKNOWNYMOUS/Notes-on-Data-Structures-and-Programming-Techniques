#include <assert.h>
#include <stdio.h>

struct Point {
    int x;
    int y;
};

struct Rectangle {
    struct Point top_left;
    int width;
    int height;
};

struct Point make_point(int x, int y);
struct Rectangle make_rectangle(struct Point top_left, int width, int height);
int area(struct Rectangle r);
int contains(struct Rectangle r, struct Point p);

int main(void) {
    struct Point p = make_point(10, 20);
    assert(p.x == 10);
    assert(p.y == 20);

    struct Rectangle r = make_rectangle(p, 5, 3);
    assert(r.top_left.x == 10);
    assert(r.top_left.y == 20);
    assert(r.width == 5);
    assert(r.height == 3);
    assert(area(r) == 15);

    assert(contains(r, make_point(10, 20)) == 1);
    assert(contains(r, make_point(14, 22)) == 1);
    assert(contains(r, make_point(15, 22)) == 0);
    assert(contains(r, make_point(14, 23)) == 0);
    assert(contains(r, make_point(9, 20)) == 0);

    puts("all struct tests passed");
    return 0;
}
