#!/usr/bin/env bash
cd "$(dirname "$0")"
set -u
pass=0
fail=0

run_check() {
  local name="$1"
  shift
  echo "==> $name"
  if "$@"; then
    echo "PASS: $name"
    pass=$((pass+1))
  else
    echo "FAIL: $name"
    fail=$((fail+1))
  fi
  echo
}

run_check "input/output/control" bash 01_input_output_control/check.sh
run_check "functions" bash 02_functions/check.sh
run_check "arrays/strings" bash 03_arrays_strings/check.sh
run_check "structs" bash 04_structs/check.sh
run_check "chapter project gradebook" bash 05_chapter_project_gradebook/check.sh

echo "Summary: $pass passed, $fail failed"
if [ "$fail" -ne 0 ]; then
  exit 1
fi
